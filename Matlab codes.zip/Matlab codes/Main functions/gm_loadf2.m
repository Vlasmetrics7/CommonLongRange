function results=gm_loadf2

data=load('loads');
loads_aux=data.loads;

loads=fracdiff(loads_aux,0.8);
[T,N]=size(loads);
[~, ~, ~, factors_aux,loadings , ~, vardec] = gdfm_onesided(loads, 3, 3, floor(sqrt(T)), floor(sqrt(T)), 1, 1);
factors= fracdiff(factors_aux,-0.8);

[yproj,f1proj,f2proj]=proj_matrix(loads_aux, factors(:,1), factors(:,2));

for i=1:24
likel=zeros(1500,1);phi1=zeros(1500,1);phi2=zeros(1500,1);
for d=0.01:0.01:1.5
    ddy=fracdiff(diff(yproj(:,i)),d-1);  
    df1=fracdiff(diff(f1proj),d-1);  
    df2=fracdiff(diff(f2proj),d-1);  
       XOLS=[df1,df2];
    BETA= (XOLS'*XOLS)^(-1)*XOLS'*ddy;
    phi1(int32(d*100),1)=BETA(1);
    phi2(int32(d*100),1)=BETA(2);
    likel(int32(d*100),1)=mean((ddy-df1.*phi1(int32(d*1000),1)-df2.*phi2(int32(d*1000),1)).^2);
end

 [a,b]=min(likel);
 dest=b/100;
 
 destdy=fracdiff(diff(yproj(:,i)),dest-1);
 destdf1=fracdiff(diff(f1proj),dest-1);
 destdf2=fracdiff(diff(f2proj),dest-1);
  
 X=[destdf1,destdf2]; 
 Z=(X'*X)^(-1)*(X'*destdy);

 phi1hat=Z(1);
 phi2hat=Z(2);
  
 e = diff(yproj(:,i))-diff(f1proj)*phi1hat-diff(f2proj)*phi2hat; 
 Xnw=[diff(f1proj) diff(f2proj)];
 se = NeweyWest(e,Xnw,0); 
 
 memest=fminbnd(@(d)(1/(T))*sum(fracdiff((diff(yproj(:,i)-phi1hat*f1proj-phi2hat*f2proj)),d-1).^2), 0, 1.5);

 results.dhatopt(i)=memest;
 results.Phi1hat(i)=phi1hat;
 results.Phi2hat(i)=phi2hat;
 results.StdPhi1(i)=se(1,1);
 results.StdPhi2(i)=se(2,1);
 
end
end


function[yproj,f1proj,f2proj]=proj_matrix(y,f1,f2)

    dy=fracdiff(y,0.8);  
    df1=fracdiff(f1,0.8);  
    df2=fracdiff(f2,0.8);
    avgystar=mean(dy');  
    
    H=[avgystar' df1 df2]';
    Hs=H'*pinv(H*H')*H;
    I=eye(size(Hs));
    W=I-Hs;              
    
    f2proj=W*f2;    
    f1proj=W*f1;   
    yproj=W*y;    

end

