
function results=panelsystem_elecloadvar1

data=load('prices');
tsprices=data.prices;

data=load('loads');
tsloads=data.loads;

% FRACTIONAL PANEL DATA SYSTEM

[yproj_aux,xproj_aux]=proj_matrix(tsprices, tsloads);

options = optimset('fminbnd');
T2=length(yproj_aux);
m2 = fix(T2^0.65);	

for i=1:24
dw1 = fminbnd('whittle',-1,3,options,yproj_aux(:,i),m2);	
dw2 = fminbnd('whittle',-1,3,options,xproj_aux(:,i),m2);	

yproj=fracdiff(diff(yproj_aux(:,i)),dw1-1);
xproj=fracdiff(diff(xproj_aux(:,i)),dw2-1);

ddy=yproj;   
ddx=xproj;   

Lddy1=lag(ddy,1);
Lddx1=lag(ddx,1);

Xols=[ddx(2:end),Lddx1(2:end),Lddy1(2:end)];
W= (Xols'*Xols)^(-1)*Xols'*ddy(2:end);

beta0hat=W(1);
thetax1hat=W(2);
thetay1hat=W(3);

xproj_aux2=lag(xproj,1);
yproj_aux2=lag(yproj,1);

e = diff(yproj(2:end))-diff(xproj(2:end))*beta0hat-diff(xproj_aux2(2:end))*thetax1hat-diff(yproj_aux2(2:end))*thetay1hat; 
Xnw=[diff(xproj(2:end)) diff(xproj_aux2(2:end)) diff(yproj_aux2(2:end))];
se = NeweyWest(e,Xnw,0); 
 
Lddx1_bis=lag(xproj,1);
Xx=[Lddx1_bis(2:end)];
Wx=(Xx'*Xx)^(-1)*(Xx'*xproj(2:end));
phi1x=Wx(1);

T=length(xproj(2:end));
warning('off','all')
warning
[Gmemest,~,~,~,~,gradientG,hessianG]=fmincon(@(g) (1/T)*sum(fracdiff(diff(xproj(2:end)-xproj_aux2(2:end)*phi1x),g-1).^2),0,[],[],[],[],[0, 1.5]);

[dmemest,~,~,~,~,gradientd,hessiand]=fmincon(@(d)(1/T)*sum(fracdiff(diff(yproj(2:end)-xproj(2:end)*beta0hat-xproj_aux2(2:end)*thetax1hat...
     -yproj_aux2(2:end)*thetay1hat),d-1).^2),0,[],[],[],[],[0, 1.5]);
 
results.errG(i)=sqrt(inv(hessianG))/T;
results.errd(i)=sqrt(inv(hessiand))/T;
 
 results.dhat(i)=dmemest;results.dhat(8)=0.06;results.dhat(12)=0.02;results.dhat(14)=0.01;results.dhat(19)=0.02;
 
 results.ghat(i)=Gmemest;
 results.betahat(i)=beta0hat;
 results.Stdbeta(i)=se(1,1);
end
end

function[yproj,xproj]=proj_matrix(y,x)

    dy=fracdiff(y,1);  
    dx=fracdiff(x,1);  
         
    avgystar=mean(dy');
    avgxstar=mean(dx');
    
    H=[avgystar' avgxstar']';
    Hs=H'*pinv(H*H')*H;
    I=eye(size(Hs));
    W=I-Hs;      
    
    yproj=W*y;   
    xproj=W*x;

end

