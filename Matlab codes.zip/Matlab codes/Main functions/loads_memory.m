function loads_memory
ff2=0.65;
data=load('loads');
loads=data.loads;


%%%%%%%%%%%%%%%%%%% LONG MEMORY ESTIMATES %%%%%%%%%%%%%%%%%%% 
options = optimset('fminbnd');
T=length(loads(:,1));
m2 = fix(T^ff2);		% m is the number of frequencies used in estimation.
dw2=zeros(1,24);
melw2=zeros(1,24);
dSD_LW2=zeros(1,24);

parfor i=1:24
dw2(i) = fminbnd('whittle',-1,3,options,loads(:,i),m2);		% LW estimate
dSD_LW2(i)=1/(2*sqrt(m2));                                       % Computing the true standard errors
melw2(i) = fminbnd('extwhittle',-0.5,2,[],loads(:,i),m2);         % Extended local Whittle Estimator
end

extmw2 = fminsearch('extmulti',melw2,[],loads,m2);
mg_ext = extmghat(extmw2,loads,m2);
mQ_ext = 2 * (mg_ext.* inv(mg_ext) + eye(24) + (pi^2)/4 * (mg_ext .* inv(mg_ext) - eye(24)));
mCov_ext = inv(mQ_ext);
se2_ext= sqrt(diag(mCov_ext)./m2);

% RESULTS
% HOURLY LOADS
Hourly_d=[dw2', melw2', extmw2'];
std_hourly_d=[dSD_LW2',dSD_LW2',se2_ext]; 
disp('FRACTIONAL MEMORY ESTIMATES OF HOURLY ELECTRICITY PRICES')
disp('       LW       EXLW     EMLW')
disp(Hourly_d)
disp('ASYMPTOTIC STANDARD DEVIATION OF FRACTIONAL MEMORY ESTIMATES OF COMMON FACTORS')
disp('       LW       EXLW     EMLW')
disp(std_hourly_d)

