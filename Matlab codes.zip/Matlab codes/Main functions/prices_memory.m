function prices_memory
ff2=0.65;
data=load('prices');
prices=data.prices;

%%%%%%%%%%%%%%%%%%% LONG MEMORY ESTIMATES %%%%%%%%%%%%%%%%%%% 
options = optimset('fminbnd');
T=length(prices(:,1));
m2 = fix(T^ff2);		
dw2=zeros(1,24);
melw2=zeros(1,24);
dSD_LW2=zeros(1,24);

parfor i=1:24
dw2(i) = fminbnd('whittle',-1,3,options,prices(:,i),m2);		% LW estimate
dSD_LW2(i)=1/(2*sqrt(m2));                                       % Computing the true standard errors
melw2(i) = fminbnd('extwhittle',-0.5,2,[],prices(:,i),m2);         % Extended local Whittle Estimator
end

extmw2 = fminsearch('extmulti',melw2,[],prices,m2);
mg_ext = extmghat(extmw2,prices,m2);
mQ_ext = 2 * (mg_ext.* inv(mg_ext) + eye(24) + (pi^2)/4 * (mg_ext .* inv(mg_ext) - eye(24)));
mCov_ext = inv(mQ_ext);
se2_ext= sqrt(diag(mCov_ext)./m2);

Hourly_d=[dw2', melw2', extmw2'];
std_hourly_d=[dSD_LW2',dSD_LW2',se2_ext]; 
disp('FRACTIONAL MEMORY ESTIMATES')
disp('       LW       EXLW     EMLW')
disp(Hourly_d)
disp('STANDARD DEVIATIONS')
disp('       LW       EXLW     EMLW')
disp(std_hourly_d)

