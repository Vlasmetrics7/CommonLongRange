function factor_prices
data=load('prices');
des_prices_aux2=data.prices;

des_prices=fracdiff(des_prices_aux2,0.84);
[T,N]=size(des_prices);

% GENERALIZED DYNAMIC FACTOR MODEL
[~, ~, ~, factors_aux, loadings, ~, vardec] = gdfm_onesided(des_prices, 3, 3, floor(sqrt(T)), floor(sqrt(T)), 1, 1);

options = optimset('fminbnd');
[K1,N1]=size(factors_aux);
factors= fracdiff(factors_aux,-0.84);

m = fix(K1^0.65);		
dmt=zeros(K1,N1);
dw=zeros(1,N1);
elw1=zeros(1,N1);
elw2=zeros(1,N1);
melw=zeros(1,N1);
dSD_LW1=zeros(1,N1);
for i=1:N1
dSD_LW1(i)=1/(2*sqrt(m));                                    
dw(i) = fminbnd('whittle',-1,3,options,factors(:,i),m);		
melw(i) = fminbnd('extwhittle',-0.5,2,[],factors(:,i),m);      
end

% COMMON FACTORS
factors_d=[dw', melw'];
disp('FRACTIONAL MEMORY ESTIMATES OF COMMON FACTORS')
disp('       dw     melw')
disp(factors_d)
disp('ASYMPTOTIC STANDARD DEVIATION OF FRACTIONAL MEMORY ESTIMATES OF COMMON FACTORS')
disp(dSD_LW1)
vardec

figure
subplot(211),bar(loadings(:,1)),subplot(212),bar(loadings(:,2))
figure
subplot(211),plot(factors(:,1)),xlabel('Factor 1'),title('Dynamic Factors'),subplot(212),plot(factors(:,2)),xlabel('Factor 2')

