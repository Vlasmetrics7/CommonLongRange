function[r] = extmulti(d,x,m)
[n,nn] = size(x);
t = (0:1:n-1)';
lambda = 2*pi*t/n;

for j=1:nn
    
    xx = x(:,j);
    k=0;

    if (d(j)>=(-1.5) && d(j)<(-0.5))
        Z = (2*pi*n)^(-1/2)*sum(xx);
        k = -exp(i*lambda).*Z;
    elseif (d(j)>=(-0.5) && d(j)<(0.5))
        k=0;
    elseif (d(j)>=(0.5) && d(j)<(1.5));
        Z1 = (2*pi*n)^(-1/2)*(xx(n,1)-xx(1,1));
        k = exp(i*lambda) .* (((1-exp(i*lambda)).^(-1)).*Z1); 
    elseif (d(j)>=(1.5) && d(j)<(2.5))
        Z1 = (2*pi*n)^(-1/2)*(xx(n,1)-xx(1,1));
        Z2 = (2*pi*n)^(-1/2)*(fracdiff(xx(n,1),1)-fracdiff(xx(1,1),1));
        k = exp(i*lambda).*(((1-exp(i*lambda)).^(-1)).*Z1+((1-exp(i*lambda)).^(-2)).*Z2);
    end
    
    wx(:,j) = (2*pi*n)^(-1/2)*conj(fft(xx)).*exp(i*lambda) + k;
end

wx = wx(2:m+1,:);

lambda = lambda(2:m+1);

for j=1:nn
    llambda(:,j) = lambda.^d(j).*exp((lambda-pi)*d(j)*i/2);
end

lw = llambda.*wx;
g = lw.'*conj(lw)/m;
rg = real(g);

r = log(det(rg)) - 2*sum(d)*mean(log(lambda));
