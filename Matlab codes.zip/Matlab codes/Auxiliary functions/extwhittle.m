function[r] = extwhittle(d,x,m)
[n,nn] = size(x);
t = (0:1:n-1)';
lambda = 2*pi*t/n;
k=0;

if (d>=(-1.5) && d<(-0.5))
    Z = (2*pi*n)^(-1/2)*sum(x);
    k = -exp(i*lambda).*Z;

elseif (d>=(-0.5) && d<(0.5))
    k=0;

elseif (d>=(0.5) && d<(1.5));
    Z1 = (2*pi*n)^(-1/2)*(x(n,1)-x(1,1));
    k = exp(i*lambda) .* (((1-exp(i*lambda)).^(-1)).*Z1); 

elseif (d>=(1.5) && d<(2.5))
    Z1 = (2*pi*n)^(-1/2)*(x(n,1)-x(1,1));
    Z2 = (2*pi*n)^(-1/2)*(fracdiff(x(n,1),1)-fracdiff(x(1,1),1));
    k = exp(i*lambda).*(((1-exp(i*lambda)).^(-1)).*Z1+((1-exp(i*lambda)).^(-2)).*Z2);
end

wx = (2*pi*n)^(-1/2)*conj(fft(conj(x))).*exp(i*lambda)+k;
lambda = lambda(2:m+1);
wx = wx(2:m+1);
Ix = wx.*conj(wx);

g = mean((lambda.^(2*d)).*Ix);
r = log(g) - 2*d*mean(log(lambda));